<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 检查文件上传
    if (isset($_FILES['zipFile']) && $_FILES['zipFile']['error'] === UPLOAD_ERR_OK) {
        // 获取文件信息
        $fileTmpPath = $_FILES['zipFile']['tmp_name'];
        $fileName = basename($_FILES['zipFile']['name']);
        $uploadDir = 'uploads/';

        // 检查文件类型
        $fileType = mime_content_type($fileTmpPath);
        if ($fileType !== 'application/zip') {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => '仅支持上传 ZIP 文件！']);
            exit;
        }

        // 检查文件大小
        $maxFileSize = 10 * 1024 * 1024; // 10MB
        if ($_FILES['zipFile']['size'] > $maxFileSize) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => '文件大小不能超过 10MB！']);
            exit;
        }

        // 确保上传目录存在
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // 处理文件名
        $fileName = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $fileName);
        $destPath = $uploadDir . $fileName;

        // 移动文件
        if (move_uploaded_file($fileTmpPath, $destPath)) {
            // 生成文件 URL
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
            $fileUrl = $protocol . $_SERVER['HTTP_HOST'] . '/' . $destPath;
            http_response_code(200);
            echo json_encode(['success' => true, 'fileUrl' => $fileUrl]);
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => '文件上传失败！']);
        }
    } else {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => '请选择一个有效的文件！']);
    }
}
?>