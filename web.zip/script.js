window.addEventListener('load', function() {
    // 页面加载完成后隐藏预加载界面
    const preloader = document.querySelector('.preloader');
    const content = document.querySelector('.content');
  
    // 淡出预加载界面
    preloader.style.opacity = '0';
    
    // 显示主要内容
    setTimeout(() => {
      preloader.style.display = 'none';
      content.style.display = 'block';
    }, 500); // 延迟0.5秒确保动画完成
  });

    const faulttext = {
        player: {},
        texts: [],
        init() {
            this.texts = [...document.getElementsByClassName('faulttext')];
        },
        fault() {
            clearInterval(this.player);
            setTimeout(() => {
                clearInterval(this.player);
                this.texts.forEach((text) => {
                    text.classList.remove("faulttext_fault");
                    text.style.transform = '';
                    text.style.clipPath = '';
                });
            }, 1000)
            this.player = setInterval(() => {
                this.texts.forEach((text) => {
                    text.classList.add("faulttext_fault");
                    text.style.transform = `translate(${Math.random() * 60 - 30}%,${Math.random() * 60 - 30}%)`;
                    let x = Math.random() * 100;
                    let y = Math.random() * 100;
                    let h = Math.random() * 50 + 50;
                    let w = Math.random() * 40 + 10;
                    text.style.clipPath = `polygon(${x}% ${y}%, ${x + w}% ${y}%, ${x + w}% ${y + h}%, ${x}% ${y + h}%)`
                })
            }, 30);
        }
    };
    faulttext.init();
